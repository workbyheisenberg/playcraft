import {capabilities,WorkflowError,unavailable} from './server/integrations.mjs';
import {draft,list,owned,view,appearanceAsset} from './server/customization.mjs';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {randomBytes,randomUUID,createHash} from 'node:crypto';
import path from 'node:path';
import {database,validWorld} from './server/db.mjs';
const db=database();db.prepare('SELECT version FROM migrations').all();
const root=path.resolve('dist');const publicUrl=process.env.APP_URL||process.env.VANTIS_PUBLIC_URL;const origins=new Set();if(publicUrl){const u=new URL(publicUrl);origins.add(u.origin);if(u.hostname.startsWith('preview-')){u.hostname='studio-'+u.hostname;origins.add(u.origin);}}

const json=(res,status,data)=>{res.writeHead(status,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(data));};
const hash=t=>createHash('sha256').update(t).digest('hex');
async function body(req){let text='';for await(const b of req){text+=b;if(text.length>2500000)throw Error('Request too large');}return JSON.parse(text);}
function validOwnedWorld(data,player){if(typeof data?.appearance==='string'&&data.appearance.startsWith('generated:')){const id=data.appearance.slice(10);return !!db.prepare('SELECT 1 FROM appearances WHERE id=? AND player=?').get(id,player)&&validWorld({...data,appearance:'ranger'});}return validWorld(data);}
export const server=createServer(async(req,res)=>{try{const pathname=new URL(req.url,'http://app').pathname;if(pathname==='/healthz'){res.writeHead(200);res.end('ok');return;}if(pathname.startsWith('/api/')){
 if(!['GET','HEAD'].includes(req.method)){const origin=req.headers.origin;const self=`${req.headers['x-forwarded-proto']==='https'?'https':'http'}://${req.headers.host}`;const browserSameOrigin=req.headers['sec-fetch-site']==='same-origin';if(!origin||!(origins.has(origin)||browserSameOrigin||(!publicUrl&&origin===self))||req.headers['x-voxel-request']!=='1')return json(res,403,{error:'This request did not come from the game. Reload and try again.'});}
 if(pathname==='/api/capabilities'&&req.method==='GET')return json(res,200,capabilities());
 let token=req.headers.cookie?.split(';').map(s=>s.trim()).find(s=>s.startsWith('grove_session='))?.slice(14);let session=token?db.prepare('SELECT player FROM sessions WHERE token=?').get(hash(token)):null;
 if(!session){token=randomBytes(32).toString('hex');const player=randomUUID();db.exec('BEGIN');try{db.prepare('INSERT INTO players(id) VALUES(?)').run(player);db.prepare('INSERT INTO sessions VALUES(?,?)').run(hash(token),player);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}session={player};const secure=publicUrl?.startsWith('https:')||req.headers['x-forwarded-proto']==='https';res.setHeader('set-cookie',`grove_session=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=31536000${secure?'; Secure':''}`);}
 if(pathname==='/api/world'&&req.method==='GET'){const row=db.prepare('SELECT * FROM worlds WHERE player=?').get(session.player);if(!row)return json(res,200,{revision:0,edits:{},position:[],selected:0,appearance:'ranger'});let data;try{data=JSON.parse(row.data);if(!validOwnedWorld(data,session.player))throw Error();}catch{return json(res,422,{error:'Your saved world could not be read. It has been preserved. Retry loading; no progress has been replaced.'});}return json(res,200,{...data,revision:row.revision});}
 if(pathname==='/api/world'&&req.method==='PUT'){const d=await body(req);if(!validOwnedWorld(d,session.player))return json(res,400,{error:'World data is invalid; the existing save is unchanged.'});db.exec('BEGIN IMMEDIATE');try{const old=db.prepare('SELECT revision FROM worlds WHERE player=?').get(session.player);if((old?.revision??0)!==d.revision){db.exec('ROLLBACK');return json(res,409,{error:'Another tab saved this world. Reload before making more changes.'});}const revision=d.revision+1;db.prepare('INSERT INTO worlds VALUES(?,?,?) ON CONFLICT(player) DO UPDATE SET revision=excluded.revision,data=excluded.data').run(session.player,revision,JSON.stringify({...d,revision}));db.exec('COMMIT');return json(res,200,{revision});}catch(e){db.exec('ROLLBACK');throw e;}}
 if(pathname==='/api/requests'&&req.method==='GET')return json(res,200,{requests:list(db,session.player)});
 if(pathname==='/api/requests'&&req.method==='POST')return json(res,200,{request:draft(db,session.player)});
 const requestRoute=pathname.match(/^\/api\/requests\/([a-f0-9-]{36})(?:\/(challenge|verify-wallet|verify-transfer|retry))?$/);
 if(requestRoute){const r=owned(db,requestRoute[1],session.player);if(!requestRoute[2]&&req.method==='GET')return json(res,200,{request:view(db,r)});if(requestRoute[2]&&req.method==='POST')unavailable();}
 if(pathname==='/api/appearances'&&req.method==='GET')return json(res,200,{appearances:db.prepare('SELECT id,request,created FROM appearances WHERE player=?').all(session.player)});
 const asset=pathname.match(/^\/api\/appearances\/([a-f0-9-]{36})\/skin$/);
 if(asset&&req.method==='GET'){const bytes=await appearanceAsset(db,asset[1],session.player);res.writeHead(200,{'content-type':'image/png','cache-control':'private, no-store','x-content-type-options':'nosniff'});return res.end(bytes);}
 if(['/api/wallet/challenge','/api/transfers/verify','/api/generation/retry'].includes(pathname))unavailable();
 return json(res,404,{error:'Unknown API route'});
 }
 const filename=path.resolve(root,'.'+decodeURIComponent(pathname));if(!filename.startsWith(root+path.sep)&&filename!==root){res.writeHead(400);return res.end();}let content,ext=path.extname(filename);try{content=await readFile(filename);}catch{if(ext){res.writeHead(404);return res.end('Not found');}content=await readFile(path.join(root,'index.html'));ext='.html';}res.writeHead(200,{'content-type':{'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'}[ext]||'application/octet-stream','x-content-type-options':'nosniff'});res.end(content);
}catch(e){if(e instanceof WorkflowError)return json(res,e.status,{error:e.message,...(e.status===503?capabilities():{})});json(res,500,{error:'Unable to complete the request. Your last saved progress is unchanged.'});}});
if(process.env.NODE_ENV!=='test')server.listen(3000,'0.0.0.0');
