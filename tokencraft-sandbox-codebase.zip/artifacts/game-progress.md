# Grove implementation and evidence

## Design
Original, calm creative voxel sandbox. Player explores a bounded 128×128×48 rolling landscape, chooses one of eight materials, removes and places blocks, and revisits saved creations. No enemies, survival, speculative rewards, or multiplayer. Creative freedom rather than time pressure is the reward. Grass ridges, sand shoreline, water and trees orient exploration. First-person controls with optional third-person inspection; earthy UI, green/cream palette, block-based original characters.

## Implementation
React/TypeScript and Three.js. Exposed-face chunk meshes, 16×16 chunks; neighboring chunks rebuilt after edits. Axis-separated AABB collision, maximum 8ms physics substeps and 50ms catch-up clamp. Six-block interaction range, occupied-space rejection, protected floor. SQLite guest sessions are opaque random cookies with hashed server storage; world revisions prevent stale writes. World data and appearance persist under /data. Migration is separate from startup. No external generated assets used.

## Checks
- npm run typecheck: passed.
- npm run build: passed; bundle warning (~777KB raw / 209KB gzip), largely Three.js.
- npm test: three suites pass: terrain/collision/placement bounds; saved-data validation; migrations, isolated guests, persistence through database reopen, conflicts, CSRF and unavailable payment endpoints.
- npm audit --omit=dev: zero vulnerabilities.
- Browser specialist: rendered world, entry, numeric selection, third-person avatar, mobile no horizontal overflow and desktop disclosure passed. Found proxied-origin 403 saving defect, repaired using browser-enforced same-origin fetch metadata plus explicit origins and custom header. Regression added. Focused browser recheck passes autosave, navigation both ways, Alpine equip and reload persistence. No new console/request errors.
- Browser jumping, block placement/removal and native Escape pointer-lock release not conclusively verified by available browser input tools. Actual process-restart browser persistence, failure injection and popstate checks remain unverified.

## Review
Checked input boundaries, SQL parameters, cookie ownership, exact origin handling, secure randomness, resource disposal and same-world revision checks. No payment can be accepted; unavailable endpoints reject server-side. Same-origin fetch metadata cannot be set by cross-origin browser JavaScript. No financial credentials or demo transactions exist. External font dependence removed.

## Unfinished approved scope / live launch blockers
Persistent account sign-in and guest-account claiming are not implemented. Current ownership is this browser's guest cookie; losing it loses access. No paid entitlement can be created.
No concrete blockchain, contract, token allowlist/decimals, attribution method, confirmation policy or payment amount treatment was supplied. Chain/signature verification and live transaction redemption processing are NOT implemented. No live launch switch exists.
No actual token metadata retrieval, image analysis, skin atlas generation, durable provider jobs or generated-asset pipeline is implemented. No providers or rights/retry/refund policies were supplied. The built-in wardrobe is explicitly free and procedural, not an AI result. Workflow text is planned flow, not simulated progress.
These limitations mean the full live-token acceptance criteria are not fulfilled. Do not enable or advertise live payments until the missing architecture/policies are agreed and implemented end-to-end.

## Customization follow-up
Implemented migration v2 without modifying v1: request history, wallet challenge/binding
storage, logo provenance, generation jobs, appearances and per-request redemption uniqueness.
Production now offers idempotent unavailable drafts owned by the browser session, real
history/detail reads, refresh, and truthful blocker snapshots. Internal adapter boundaries
cover canonical evidence predicates, decimal-safe 100,000-token arithmetic, challenge
consumption, unique redemption, staged processing, stable provider job keys, reconciliation,
leases/timeouts, retained entitlement, original PNG provenance and validated 192×16 skin
atlases. Client supports owned generated texture preview/equipping without changing geometry.

No production adapter or worker is registered, no network is assumed, and no live endpoints
were enabled. See server/INTEGRATIONS.md for exact unfinished work and trust contracts.
The prior section saying no pipeline exists is superseded only for these internal boundaries;
concrete chain/provider/account integrations and live acceptance remain unfinished.

Final checks: typecheck and production build pass (existing bundle-size warning remains).
Six automated suites pass, including fresh HTTP-session draft isolation and access rejection,
idempotent draft creation, unavailable verify endpoint, synthetic evidence rejection,
duplicate redemption rollback, expired/consumed challenge rejection, generation failure
retaining entitlement, reconciliation-key reuse, asset ownership and PNG validation.
Fixture images and evidence are confined to temporary test directories, never seeded.
Browser review passes draft creation/idempotency/details/reload, truthful unpaid status,
wardrobe equip and world navigation, mobile overflow/disclosure, and no console/request
errors. Browser fresh-session isolation and live/generated-provider flow unverified;
fresh-session isolation is independently covered by direct HTTP tests.
