export const SIZE=128, HEIGHT=48;
export const palette=[{name:'Meadow',color:'#7eaa50'},{name:'Earth',color:'#957052'},{name:'Stone',color:'#929a9b'},{name:'Sand',color:'#e0c68b'},{name:'Timber',color:'#866140'},{name:'Leaves',color:'#4d854c'},{name:'Clay',color:'#ba795c'},{name:'Chalk',color:'#e2dfce'}];
export type Saved={revision:number; edits:Record<string,number>; position:number[]; selected:number; appearance:string};
export const key=(x:number,y:number,z:number)=>`${x},${y},${z}`;
export function ground(x:number,z:number){return Math.floor(8+Math.sin(x*.085)*3+Math.cos(z*.095)*3+Math.sin((x+z)*.17)*1.5);}
export function base(x:number,y:number,z:number):number{if(x<0||z<0||x>=SIZE||z>=SIZE||y<0)return 3;if(y>=HEIGHT)return 0;const h=ground(x,z);if(y<=h)return y===h?(h<7?4:1):y>h-3?2:3;for(let a=Math.floor((x-2)/9);a<=Math.floor((x+2)/9);a++)for(let b=Math.floor((z-2)/9);b<=Math.floor((z+2)/9);b++){const tx=a*9+4,tz=b*9+4;if((a*7+b*3)%5!==0)continue;const th=ground(tx,tz);if(th<8)continue;if(x===tx&&z===tz&&y<=th+4&&y>th)return 5;if(Math.abs(x-tx)<=2&&Math.abs(z-tz)<=2&&y>=th+3&&y<=th+5&&(Math.abs(x-tx)+Math.abs(z-tz)<4))return 6;}return 0;}
export class World{edits:Record<string,number>;constructor(edits:Record<string,number>={}){this.edits={...edits};}get(x:number,y:number,z:number){return this.edits[key(x,y,z)]??base(x,y,z);}set(x:number,y:number,z:number,id:number){if(y<=0||y>=HEIGHT||x<0||z<0||x>=SIZE||z>=SIZE)return false;this.edits[key(x,y,z)]=id;return true;}}
export function intersects(px:number,py:number,pz:number,x:number,y:number,z:number){return px+.29>x&&px-.29<x+1&&py+1.75>y&&py<y+1&&pz+.29>z&&pz-.29<z+1;}
export function collides(w:World,p:number[]){for(let x=Math.floor(p[0]-.29);x<=Math.floor(p[0]+.29);x++)for(let y=Math.floor(p[1]);y<=Math.floor(p[1]+1.75);y++)for(let z=Math.floor(p[2]-.29);z<=Math.floor(p[2]+.29);z++)if(w.get(x,y,z))return true;return false;}
export const spawn=()=>[62.5,ground(62,62)+1.02,62.5];
